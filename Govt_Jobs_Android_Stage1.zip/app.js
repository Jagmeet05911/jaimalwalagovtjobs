(() => {
  const KEY = "govtJobsStage1DataV1";
  const $ = (id) => document.getElementById(id);
  const today = new Date();
  const todayISO = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
  $("sourceChecked").value = todayISO;
  let english = false;
  let data = load();

  function load() {
    try {
      const v = JSON.parse(localStorage.getItem(KEY) || '{"jobs":[]}');
      return v && Array.isArray(v.jobs) ? v : {jobs:[]};
    } catch { return {jobs:[]}; }
  }
  function save() { localStorage.setItem(KEY, JSON.stringify(data)); render(); }
  function esc(s="") { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function toast(msg) {
    $("toast").textContent = msg; $("toast").classList.remove("hidden");
    clearTimeout(toast.timer); toast.timer = setTimeout(()=>$("toast").classList.add("hidden"), 2800);
  }
  function dateFmt(s) { if(!s) return "ਦਰਜ ਨਹੀਂ"; const p=s.split("-"); return p.length===3 ? `${p[2]}-${p[1]}-${p[0]}` : s; }
  function card(j, admin=false) {
    return `<article class="job-card">
      <h3>${esc(j.title)}</h3><div class="job-meta"><strong>${esc(j.department)}</strong>${j.location ? " • "+esc(j.location):""}</div>
      ${j.eligibility ? `<p class="job-description"><strong>ਯੋਗਤਾ:</strong> ${esc(j.eligibility)}</p>`:""}
      ${j.age ? `<p class="job-meta">ਉਮਰ ਹੱਦ: ${esc(j.age)}</p>`:""}
      ${j.deadline ? `<p class="job-meta">ਆਖ਼ਰੀ ਮਿਤੀ: <strong>${esc(dateFmt(j.deadline))}</strong></p>`:""}
      <p class="job-meta">ਨੋਟਿਸ ਜਾਂਚਿਆ: ${esc(dateFmt(j.sourceChecked))}</p>
      <p><a class="external" href="${esc(j.noticeUrl)}" target="_blank" rel="noopener noreferrer">ਅਧਿਕਾਰਤ ਨੋਟਿਸ ਖੋਲ੍ਹੋ ↗</a></p>
      ${j.applyUrl ? `<p><a class="external" href="${esc(j.applyUrl)}" target="_blank" rel="noopener noreferrer">ਅਪਲਾਈ ਲਿੰਕ ↗</a></p>`:""}
      ${j.test ? `<span class="pill amber">TEST ENTRY — ਅਸਲੀ ਨੌਕਰੀ ਨਹੀਂ</span>`:""}
      ${admin ? `<div class="actions">
        ${j.status==="pending" ? `<button class="approve" data-action="approve" data-id="${esc(j.id)}">Approve / ਪਬਲਿਸ਼</button><button class="reject" data-action="reject" data-id="${esc(j.id)}">Reject</button>` : `<button class="secondary" data-action="unpublish" data-id="${esc(j.id)}">Unpublish</button>`}
        <button class="reject" data-action="delete" data-id="${esc(j.id)}">Delete</button>
      </div>` : `<div class="actions"><button class="secondary" data-action="save" data-id="${esc(j.id)}">${j.saved ? "Saved ✓" : "ਨੌਕਰੀ ਸੇਵ ਕਰੋ"}</button></div>`}
    </article>`;
  }
  function listInto(el, items, emptyText, admin=false) {
    el.classList.toggle("empty", items.length===0);
    el.innerHTML = items.length ? items.map(j=>card(j,admin)).join("") : `<p>${esc(emptyText)}</p>`;
  }
  function render() {
    const q = ($("searchInput").value||"").trim().toLowerCase();
    const published = data.jobs.filter(j=>j.status==="published" && (!q || [j.title,j.department,j.location,j.eligibility].join(" ").toLowerCase().includes(q)));
    const pending = data.jobs.filter(j=>j.status==="pending");
    const allPublished = data.jobs.filter(j=>j.status==="published");
    $("publishedCount").textContent = `${allPublished.length} ਪਬਲਿਸ਼`;
    $("pendingCount").textContent = pending.length;
    $("adminPublishedCount").textContent = allPublished.length;
    listInto($("jobsList"), published, "ਹਾਲੇ ਕੋਈ ਮਨਜ਼ੂਰ ਨੌਕਰੀ ਨਹੀਂ। ਕੋਈ ਅਸਲੀ ਨੌਕਰੀ ਇੱਥੇ ਆਪਣੇ ਆਪ ਨਹੀਂ ਆਉਂਦੀ।");
    listInto($("pendingList"), pending, "ਕੋਈ Pending ਐਂਟਰੀ ਨਹੀਂ।", true);
    listInto($("adminPublishedList"), allPublished, "ਹਾਲੇ ਕੁਝ ਪਬਲਿਸ਼ ਨਹੀਂ ਕੀਤਾ ਗਿਆ।", true);
    listInto($("savedList"), allPublished.filter(j=>j.saved), "ਤੁਸੀਂ ਹਾਲੇ ਕੋਈ ਨੌਕਰੀ ਸੇਵ ਨਹੀਂ ਕੀਤੀ।");
  }
  function showView(name) {
    ["jobs","saved","admin"].forEach(v => {
      $(v+"View").classList.toggle("hidden", v!==name);
      $(v+"Tab").classList.toggle("active", v===name);
    });
  }
  document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
  $("searchInput").addEventListener("input",render);

  $("jobForm").addEventListener("submit", e=>{
    e.preventDefault();
    const noticeUrl = $("noticeUrl").value.trim(), applyUrl = $("applyUrl").value.trim();
    if (!/^https:\/\/.+/i.test(noticeUrl) || (applyUrl && !/^https:\/\/.+/i.test(applyUrl))) {
      toast("ਸੁਰੱਖਿਆ ਲਈ ਅਧਿਕਾਰਤ ਲਿੰਕ https:// ਨਾਲ ਸ਼ੁਰੂ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ।"); return;
    }
    const j = {
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+Math.random().toString(16).slice(2)),
      title:$("title").value.trim(), department:$("department").value.trim(), location:$("location").value.trim(),
      eligibility:$("eligibility").value.trim(), age:$("age").value.trim(), deadline:$("deadline").value,
      noticeUrl, applyUrl, sourceChecked:$("sourceChecked").value, test:$("isTest").checked,
      status:"pending", saved:false, createdAt:new Date().toISOString()
    };
    if (!j.title || !j.department || !j.sourceChecked) { toast("ਤਾਰਾ (*) ਵਾਲੇ ਖਾਨੇ ਭਰੋ।"); return; }
    data.jobs.unshift(j); save(); e.target.reset(); $("sourceChecked").value=todayISO;
    showView("admin"); toast("Pending ਵਿੱਚ ਸੇਵ ਹੋ ਗਿਆ — ਹਾਲੇ ਪਬਲਿਸ਼ ਨਹੀਂ ਹੋਇਆ।");
  });

  document.body.addEventListener("click", e=>{
    const b=e.target.closest("button[data-action]"); if(!b) return;
    const j=data.jobs.find(x=>x.id===b.dataset.id); if(!j) return;
    switch(b.dataset.action) {
      case "approve":
        if (!confirm("ਕੀ ਤੁਸੀਂ ਅਧਿਕਾਰਤ ਨੋਟਿਸ, ਯੋਗਤਾ ਅਤੇ ਆਖ਼ਰੀ ਮਿਤੀ ਚੈੱਕ ਕਰ ਲਈ ਹੈ? Approve ਕਰਨ ਨਾਲ ਇਹ ਇਸੇ ਟੈਸਟ ਐਪ ਦੀ Published ਸੂਚੀ ਵਿੱਚ ਦਿਖੇਗੀ।")) return;
        j.status="published"; j.approvedAt=new Date().toISOString(); save(); toast("ਇਸ ਡਿਵਾਈਸ ਦੀ ਸੂਚੀ ਵਿੱਚ Published ਹੋ ਗਿਆ।"); break;
      case "reject": j.status="rejected"; save(); toast("Rejected — ਜਨਤਕ ਸੂਚੀ ਵਿੱਚ ਨਹੀਂ ਦਿਖੇਗਾ।"); break;
      case "unpublish": j.status="pending"; save(); toast("Unpublished ਕਰ ਦਿੱਤਾ।"); break;
      case "delete": if(confirm("ਇਹ ਐਂਟਰੀ ਪੱਕੇ ਤੌਰ 'ਤੇ ਮਿਟਾਉਣੀ ਹੈ?")) { data.jobs=data.jobs.filter(x=>x.id!==j.id); save(); toast("ਐਂਟਰੀ ਮਿਟਾ ਦਿੱਤੀ।"); } break;
      case "save": j.saved=!j.saved; save(); break;
    }
  });
  $("resetBtn").addEventListener("click",()=>{
    if(confirm("ਕੀ ਤੁਸੀਂ ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਦਾ ਸਾਰਾ Govt Jobs ਟੈਸਟ ਡਾਟਾ ਮਿਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?")) {
      data={jobs:[]}; save(); toast("ਲੋਕਲ ਟੈਸਟ ਡਾਟਾ ਮਿਟਾ ਦਿੱਤਾ।");
    }
  });
  $("langBtn").addEventListener("click",()=>{
    english=!english;
    $("langBtn").textContent=english?"ਪੰਜਾਬੀ":"English";
    $("subtitle").textContent=english?"Government vacancies • Punjabi + English":"ਸਰਕਾਰੀ ਨੌਕਰੀਆਂ • ਪੰਜਾਬੀ + English";
    $("jobsTab").textContent=english?"Jobs":"ਨੌਕਰੀਆਂ";
    $("savedTab").textContent=english?"Saved":"ਸੇਵ ਕੀਤੀਆਂ";
    $("jobsHeading").textContent=english?"Published vacancies":"ਨੌਕਰੀਆਂ";
    $("jobsIntro").textContent=english?"Only approved vacancies appear here.":"ਮਨਜ਼ੂਰ ਕੀਤੀਆਂ ਨੌਕਰੀਆਂ ਇੱਥੇ ਦਿਖਣਗੀਆਂ।";
    $("searchLabel").textContent=english?"Search vacancies":"ਨੌਕਰੀ ਖੋਜੋ";
    $("searchInput").placeholder=english?"Department, post or eligibility":"ਵਿਭਾਗ, ਅਹੁਦਾ ਜਾਂ ਯੋਗਤਾ";
    $("emptyJobsTitle").textContent=english?"No approved vacancies yet":"ਹਾਲੇ ਕੋਈ ਮਨਜ਼ੂਰ ਨੌਕਰੀ ਨਹੀਂ";
    $("emptyJobsText").textContent=english?"Vacancies should be checked and approved in Admin Panel.":"ਨਵੀਆਂ ਭਰਤੀਆਂ ਦੀ ਜਾਂਚ ਕਰਕੇ Admin Panel ਰਾਹੀਂ ਮਨਜ਼ੂਰ ਕੀਤੀਆਂ ਜਾਣਗੀਆਂ।";
    $("savedHeading").textContent=english?"Saved vacancies":"ਸੇਵ ਕੀਤੀਆਂ ਨੌਕਰੀਆਂ";
  });
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
  }
  render();
})();